NOTE: This demo font is for PERSONAL USE ONLY! But any donation is very appreciated. 

Please contact me before any commercial use.
My fonts for free use allowed only in personal projects, non-profit and charity use.
If you make money from using my fonts, Please purchase a commercial license

Link to purchase FULL VERSION and COMMERCIAL LICENSE: 
https://gumroad.com/alpaprana

Paypal account for donation : 
https://paypal.me/alpaprana

For information please email:
alpapranastudio@gmail.com

Thank you :)

Best
Alpaprana


====================================

INDONESIA - MOHON DIBACA:
Halo, perlu diketahui bahwa font ini hanyak untuk penggunaan PERSONAL SAJA .
Tidak diperbolehkan untuk penggunaan KOMERSIL apapun kecuali anda membeli LISENSI-nya terlebih dahulu.
Lisensi bisa anda beli di :
https://gumroad.com/alpaprana

Apabila anda melanggar/menggunakan untuk kebutuhan komersil tanpa membeli lisensinya terlebih dahulu,
anda akan dikenakan biaya minimal Rp 25.000.000 (Dua Puluh Lima Juta Rupiah)

Terima kasih , mohon saling support ya :)